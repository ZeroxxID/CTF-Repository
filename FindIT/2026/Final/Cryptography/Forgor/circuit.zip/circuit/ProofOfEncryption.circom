pragma circom 2.0.0;

include "../node_modules/circomlib/circuits/poseidon.circom";
include "./lib/ChaCha20/chacha20-bits.circom";

template Key2Num() {
    signal input in[8][32];
    signal output out[2];
    
    for (var k = 0; k < 2; k++) {
        var lc = 0;
        var e = 1;
        for (var i = k*4; i < ((k+1) * 4); i++) {
            for (var j = 31; j >= 0; j--) {
                lc += in[i][j] * e;
                e = e + e;
            }
        }
        lc ==> out[k];
    }
}

template ProofOfEncryption(N) {

    signal input plaintext[N][32];       
    signal input encryptionKey[8][32];   

    signal input encryptionNonce[3][32]; 
    signal input encryptionCounter[32];  
    signal input zkNonce;

    signal output ciphertext[N][32];     
    signal output authHash;

    component chacha20 = ChaCha20(N, 32);
    chacha20.key     <== encryptionKey;
    chacha20.nonce   <== encryptionNonce;
    chacha20.counter <== encryptionCounter;
    chacha20.in      <== plaintext;
    ciphertext       <== chacha20.out;

    component key2Num = Key2Num();
    key2Num.in <== encryptionKey;

    component authHasher = Poseidon(3);
    authHasher.inputs <== [key2Num.out[0], key2Num.out[1], zkNonce];
    authHash <== authHasher.out;
}

component main {public [encryptionNonce, encryptionCounter, zkNonce]} = ProofOfEncryption(32);
