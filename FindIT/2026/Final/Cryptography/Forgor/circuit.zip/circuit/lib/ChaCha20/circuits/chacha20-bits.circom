pragma circom 2.0.0;

include "./chacha-round.circom";
include "./chacha-qr.circom";
include "./generics-bits.circom";

template ChaCha20(N, BITS_PER_WORD) {
    signal input key[8][BITS_PER_WORD];
    signal input nonce[3][BITS_PER_WORD];
    signal input counter[BITS_PER_WORD];
    signal input in[N][BITS_PER_WORD];
    signal output out[N][BITS_PER_WORD];

    var tmp[16][BITS_PER_WORD] = [
        [
            0, 1, 1, 0, 0, 0, 0, 1, 0,
            1, 1, 1, 0, 0, 0, 0, 0, 1,
            1, 1, 1, 0, 0, 0, 0, 1, 1,
            0, 0, 1, 0, 1
        ],
        [
            0, 0, 1, 1, 0, 0, 1, 1, 0,
            0, 1, 0, 0, 0, 0, 0, 0, 1,
            1, 0, 0, 1, 0, 0, 0, 1, 1,
            0, 1, 1, 1, 0
        ],
        [
            0, 1, 1, 1, 1, 0, 0, 1, 0,
            1, 1, 0, 0, 0, 1, 0, 0, 0,
            1, 0, 1, 1, 0, 1, 0, 0, 1,
            1, 0, 0, 1, 0
        ],
        [
            0, 1, 1, 0, 1, 0, 1, 1, 0,
            0, 1, 0, 0, 0, 0, 0, 0, 1,
            1, 0, 0, 1, 0, 1, 0, 1, 1,
            1, 0, 1, 0, 0
        ],
        key[0], key[1], key[2], key[3], key[4], key[5], key[6], key[7],
        counter,
        nonce[0], nonce[1], nonce[2]
    ];

    signal one[BITS_PER_WORD];
    one <== [
        0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 1
    ];

    var i = 0;
    var j = 0;

    component rounds[N / 16];
    component xors[N];
    component counter_adder[N / 16 - 1];

    for (i = 0; i < N / 16; i++) {
        rounds[i] = Round(BITS_PER_WORD);
        rounds[i].in <== tmp;
        for (j = 0; j < 16; j++) {
            xors[i * 16 + j] = XorBits(BITS_PER_WORD);
            xors[i * 16 + j].a <== in[i * 16 + j];
            xors[i * 16 + j].b <== rounds[i].out[j];
            out[i * 16 + j] <== xors[i * 16 + j].out;
        }

        if (i < N / 16 - 1) {
            counter_adder[i] = AddBits(BITS_PER_WORD);
            counter_adder[i].a <== tmp[12];
            counter_adder[i].b <== one;

            tmp[12] = counter_adder[i].out;
        }
    }
}
