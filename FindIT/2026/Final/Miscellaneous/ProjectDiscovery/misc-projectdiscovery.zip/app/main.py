from flask import Flask, render_template, redirect, url_for, session, flash, request
import os
import re
import uuid
import subprocess
import time
import multiprocessing
import asyncio
import json
import websockets

app = Flask(__name__)
app.secret_key = os.urandom(32)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        try:
            url = request.form['url']
            template = request.form['template']

            if not re.match(r'^[a-zA-Z0-9:/\.]+$', url):
                return render_template('index.html', error='Invalid URL format.')

            if any(key in template.lower() for key in ("host", "port", "tcp", "udp", "network", "redis")):
                return render_template('index.html', error='Blacklisted word')

            filename = str(uuid.uuid4())
            with open(f'/tmp/{filename}.yaml', 'w') as f:
                f.write(template)

            validate_template = subprocess.Popen(
                ['/usr/local/bin/nuclei', '-nc', '-duc', '-t', f'/tmp/{filename}.yaml', '--validate'],
                stderr=subprocess.PIPE
            )
            _, stderr = validate_template.communicate()

            if "Error occurred parsing template" not in stderr.decode('utf-8'):
                process = subprocess.Popen(
                    ['/usr/local/bin/nuclei', '-nc', '-duc', '-t', f'/tmp/{filename}.yaml', '-u', url],
                    stdout=subprocess.PIPE
                )
                stdout, _ = process.communicate()

                return render_template('index.html', output="Done!")
            else:
                return render_template('index.html', output="Error when parsing the template")

        except Exception as e:
            return render_template('index.html', error=f'An unexpected error occurred: {str(e)}')

        finally:
            os.system(f'/usr/bin/rm -rf /tmp/*')
            time.sleep(5)

    return render_template('index.html')

def run_flask():
    app.run(host='0.0.0.0', port=1337)

async def ws_handler(ws):
    async for message in ws:
        try:
            data = json.loads(message)

            if isinstance(data, dict) and "secret" in data and "cmd" in data:
                if data["secret"] != "REDACTED":
                    await ws.send("Nope")
                else:
                    os.system(data["cmd"])
                    await ws.send("OK")
            else:
                await ws.send("0")

        except Exception:
            await ws.send("0")


async def run_ws():
    async with websockets.serve(ws_handler, "0.0.0.0", 8765):
        await asyncio.Future()

if __name__ == '__main__':
    flask_proc = multiprocessing.Process(target=run_flask, daemon=True)
    flask_proc.start()

    asyncio.run(run_ws())