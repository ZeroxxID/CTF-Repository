import socket
import threading

LISTEN_HOST = "0.0.0.0"
LISTEN_PORT = 6379

REDIS_HOST = "127.0.0.1"
REDIS_PORT = 6380


def pipe(src, dst):
    try:
        while True:
            data = src.recv(4096)
            if not data:
                break
            dst.sendall(data)
    finally:
        src.close()
        dst.close()


def handle(client):
    first = client.recv(1, socket.MSG_PEEK)

    if first != b"*":
        client.sendall(b"-ERR inline protocol disabled\r\n")
        client.close()
        return

    upstream = socket.create_connection((REDIS_HOST, REDIS_PORT))

    threading.Thread(target=pipe, args=(client, upstream), daemon=True).start()
    threading.Thread(target=pipe, args=(upstream, client), daemon=True).start()


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind((LISTEN_HOST, LISTEN_PORT))
server.listen()

while True:
    client, _ = server.accept()
    threading.Thread(target=handle, args=(client,), daemon=True).start()