#!/usr/bin/env python3
import os
import random
import secrets

FLAG = open(os.environ.get('FLAG_PATH', '/flag.txt'), 'r').read().strip()
FLAG_PRICE = 50000
STARTING_BALANCE = 1000


def prompt_int(label, lower, upper):
    raw = input(label).strip()
    value = int(raw)
    if value < lower or value > upper:
        raise ValueError
    return value


def next_ticket(rng):
    return rng.getrandbits(32)


def play_roulette(balance, rng):
    print('roulette table')
    stake = prompt_int('stake: ', 1, balance)
    guess = prompt_int('number (0-36): ', 0, 36)
    ticket = next_ticket(rng)
    winning = ticket % 37
    color = 'green' if winning == 0 else ('red' if winning % 2 else 'black')
    print(f'wheel: {winning} {color}')
    print(f'ticket id: {ticket:08x}')
    if guess == winning:
        payout = stake * 36
        balance = balance - stake + payout
        print(f'jackpot hit, paid {payout} credits')
    else:
        balance -= stake
        print('no payout this round')
    return balance


def play_slots(balance, rng):
    print('slots terminal')
    stake = prompt_int('stake: ', 1, balance)
    ticket = next_ticket(rng)
    symbols = ['Nova', 'Bell', 'Cherry', 'Seven']
    reels = [symbols[(ticket >> shift) & 0x3] for shift in (0, 2, 4)]
    print('reels: ' + ' | '.join(reels))
    print(f'ticket id: {ticket:08x}')
    if len(set(reels)) == 1:
        payout = stake * 8
        balance = balance - stake + payout
        print(f'line winner, paid {payout} credits')
    else:
        balance -= stake
        print('no payout this round')
    return balance


def buy_flag(balance):
    if balance < FLAG_PRICE:
        print(f'vip counter says you need {FLAG_PRICE} credits for the collector token')
        return False
    print(FLAG)
    return True


def main():
    balance = STARTING_BALANCE
    rng = random.Random(secrets.randbits(256))
    print('=== Starline Casino ===')
    print('Each guest session runs its own fairness stream for audit review.')

    while True:
        print()
        print(f'Balance: {balance} credits')
        print('1. Play roulette')
        print('2. Spin slots')
        print(f'3. Buy VIP flag ({FLAG_PRICE} credits)')
        print('4. Exit')
        choice = input('> ').strip()

        try:
            if choice == '1':
                balance = play_roulette(balance, rng)
            elif choice == '2':
                balance = play_slots(balance, rng)
            elif choice == '3':
                if buy_flag(balance):
                    return
            elif choice == '4':
                print('come back soon')
                return
            else:
                print('invalid option')
        except Exception:
            print('table manager rejected that input')


if __name__ == '__main__':
    main()
